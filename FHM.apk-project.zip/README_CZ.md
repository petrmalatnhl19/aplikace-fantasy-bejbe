# Fantasy Hockey Manager – Android APK

Tento projekt zabalí aktuální webovou aplikaci `index.html` do jednoduché Android aplikace pomocí WebView. HTML je uloženo přímo v APK, takže základní rozhraní funguje i bez připojení k internetu. Funkce vyžadující živá data nebo Yahoo API ale bez jejich propojení fungovat nezačnou.

## Jak získat APK bez instalace Android Studia

1. Vytvoř nový GitHub repozitář (např. `fantasy-hockey-manager-apk`).
2. Nahraj do něj celý obsah této složky, včetně skryté složky `.github`.
3. Otevři v repozitáři kartu **Actions**.
4. Vyber workflow **Build Android APK** a stiskni **Run workflow**, případně počkej na dokončení automatického buildu po nahrání souborů.
5. Po úspěšném běhu otevři dokončený běh workflow a v části **Artifacts** stáhni `Fantasy-Hockey-Manager-APK`.
6. Rozbal ZIP s artefaktem. Soubor `app-debug.apk` nainstaluj na Androidu. Telefon může požádat o povolení instalace aplikací z daného zdroje.

## Důležité

- Toto je **debug APK** pro vlastní testování, ne podepsaná produkční verze pro Google Play.
- Aktuální `index.html` je zkopírovaný do `app/src/main/assets/index.html`. Pokud web později upravíš, zkopíruj novou verzi na toto místo a znovu spusť build.
- Neobsahuje přihlašovací údaje Yahoo ani implementaci Yahoo API.
- Balíček má identifikátor `cz.petrmalat.fantasyhockey`.
